Development Lead
----------------

- Ian Stapleton Cordasco <graffatcolmingov@gmail.com>

Contributors
------------

- Brett Cannon
- Daniel Imhoff
- Eugene Eeo
- Jeff Potter
- Philippe Ombredanne
- Thierry Bastian
- Thomas Grainger
